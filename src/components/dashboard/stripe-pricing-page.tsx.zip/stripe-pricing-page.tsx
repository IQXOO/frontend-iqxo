"use client";

import { useState, useEffect, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Crown,
  Check,
  X,
  Gift,
  Clock,
  Mic,
  ImageIcon,
  Brain,
  Lightbulb,
  Zap,
  Lock,
  AlertCircle,
  CreditCard,
  Smartphone,
  Building2,
  ChevronRight,
  Shield,
  RefreshCw,
  CheckCircle2,
  XCircle,
  ArrowLeft,
  Sparkles,
  Info,
} from "lucide-react";
import { useApp } from "../../lib/store";

// ─────────────────────────────────────────────────────────────────────────────
// TYPES
// ─────────────────────────────────────────────────────────────────────────────
type BillingCycle = "monthly" | "yearly";
type PaymentMethod = "card" | "apple_pay" | "google_pay" | "sepa" | "paypal";
type PageStep = "plans" | "payment" | "processing" | "success" | "error";

interface PricingConfig {
  monthlyEUR: number;
  yearlyEUR: number;
  yearlyPerMonth: string;
  savingsPct: number;
}

const PRICING: PricingConfig = {
  monthlyEUR: 9.99,
  yearlyEUR: 79,
  yearlyPerMonth: (79 / 12).toFixed(2),
  savingsPct: Math.round(100 - (79 / (9.99 * 12)) * 100),
};

// const PRICE_IDS: Record<BillingCycle, string> = {
//   monthly:
//     (import.meta as any).env?.VITE_STRIPE_MONTHLY_PRICE_ID || "price_monthly",
//   yearly:
//     (import.meta as any).env?.VITE_STRIPE_YEARLY_PRICE_ID || "price_yearly",
// };

const BACKEND_URL =
  (import.meta as any).env?.VITE_BACKEND_API || "http://localhost:4000";

// ─────────────────────────────────────────────────────────────────────────────
// HELPERS
// ─────────────────────────────────────────────────────────────────────────────
function useTranslate(language: string) {
  return (en: string, fr: string, ar: string) =>
    language === "ar" ? ar : language === "fr" ? fr : en;
}

function formatCardNumber(value: string): string {
  const v = value.replace(/\D/g, "").slice(0, 16);
  return v.replace(/(.{4})/g, "$1 ").trim();
}

function formatExpiry(value: string): string {
  const v = value.replace(/\D/g, "").slice(0, 4);
  if (v.length >= 3) return v.slice(0, 2) + "/" + v.slice(2);
  return v;
}

function formatIBAN(value: string): string {
  const v = value.replace(/\s/g, "").toUpperCase().slice(0, 34);
  return v.replace(/(.{4})/g, "$1 ").trim();
}

function detectCardBrand(number: string): string {
  const n = number.replace(/\s/g, "");
  if (/^4/.test(n)) return "visa";
  if (/^5[1-5]|^2[2-7]/.test(n)) return "mastercard";
  if (/^3[47]/.test(n)) return "amex";
  return "generic";
}

// ─────────────────────────────────────────────────────────────────────────────
// CARD BRAND ICON
// ─────────────────────────────────────────────────────────────────────────────
function CardBrandIcon({ brand }: { brand: string }) {
  if (brand === "visa")
    return (
      <div className="h-5 w-9 rounded bg-[#1A1F71] flex items-center justify-center px-1">
        <span
          className="text-[9px] font-black italic tracking-wider"
          style={{ color: "#fff", fontFamily: "serif" }}
        >
          VISA
        </span>
      </div>
    );
  if (brand === "mastercard")
    return (
      <div className="h-5 w-9 flex items-center justify-center">
        <div className="w-4 h-4 rounded-full bg-[#EB001B] opacity-90 -mr-1.5 z-10" />
        <div className="w-4 h-4 rounded-full bg-[#F79E1B] opacity-90" />
      </div>
    );
  if (brand === "amex")
    return (
      <div className="h-5 w-9 rounded bg-[#007BC1] flex items-center justify-center">
        <span className="text-[8px] font-black text-white tracking-tighter">
          AMEX
        </span>
      </div>
    );
  return (
    <div className="h-5 w-9 rounded bg-white/10 flex items-center justify-center">
      <CreditCard className="w-3.5 h-3.5 text-white/40" />
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// PAYMENT METHOD SELECTOR
// ─────────────────────────────────────────────────────────────────────────────
function PaymentMethodSelector({
  selected,
  onChange,
  language,
}: {
  selected: PaymentMethod;
  onChange: (m: PaymentMethod) => void;
  language: string;
}) {
  const t = useTranslate(language);

  // Detect Apple/Google Pay availability
  const [hasApplePay] = useState(() => {
    try {
      return !!(window as any).ApplePaySession?.canMakePayments?.();
    } catch {
      return false;
    }
  });
  const [hasGooglePay] = useState(() => {
    const ua = navigator.userAgent.toLowerCase();
    return ua.includes("android") || ua.includes("chrome");
  });

  const methods: {
    id: PaymentMethod;
    label: string;
    icon: React.ReactNode;
    available: boolean;
  }[] = [
    {
      id: "card",
      label: t("Credit / Debit Card", "Carte bancaire", "بطاقة ائتمانية"),
      icon: <CreditCard className="w-4 h-4" />,
      available: true,
    },
    {
      id: "apple_pay",
      label: "Apple Pay",
      icon: (
        <svg viewBox="0 0 24 24" className="w-4 h-4 fill-current">
          <path d="M17.05 20.28c-.98.95-2.05.8-3.08.35-1.09-.46-2.09-.48-3.24 0-1.44.62-2.2.44-3.06-.35C2.79 15.25 3.51 7.7 9.05 7.43c1.35.07 2.29.74 3.08.8 1.18-.24 2.31-.93 3.57-.84 1.51.12 2.65.72 3.4 1.8-3.12 1.87-2.38 5.98.48 7.13-.57 1.39-1.32 2.76-2.54 3.96zM12.03 7.25c-.15-2.23 1.66-4.07 3.74-4.25.29 2.58-2.34 4.5-3.74 4.25z" />
        </svg>
      ),
      available: hasApplePay,
    },
    {
      id: "google_pay",
      label: "Google Pay",
      icon: (
        <svg viewBox="0 0 24 24" className="w-4 h-4 fill-current">
          <path
            d="M20.66 12.2c0-.61-.05-1.2-.15-1.77H12v3.35h4.84a4.14 4.14 0 01-1.8 2.72v2.26h2.92c1.71-1.57 2.7-3.89 2.7-6.56z"
            fill="#4285F4"
          />
          <path
            d="M12 21c2.43 0 4.47-.8 5.96-2.18l-2.91-2.26c-.81.54-1.84.86-3.05.86-2.34 0-4.33-1.58-5.04-3.71H3.95v2.33A9 9 0 0012 21z"
            fill="#34A853"
          />
          <path
            d="M6.96 13.71a5.41 5.41 0 010-3.42V7.96H3.95a9 9 0 000 8.08l3.01-2.33z"
            fill="#FBBC04"
          />
          <path
            d="M12 6.58c1.32 0 2.5.45 3.44 1.35l2.58-2.58A9 9 0 003.95 7.96l3.01 2.33C7.67 8.16 9.66 6.58 12 6.58z"
            fill="#EA4335"
          />
        </svg>
      ),
      available: hasGooglePay,
    },
    {
      id: "sepa",
      label: t("SEPA Direct Debit", "Prélèvement SEPA", "خصم SEPA"),
      icon: <Building2 className="w-4 h-4" />,
      available: true,
    },
    {
      id: "paypal",
      label: "PayPal",
      icon: (
        <svg
          viewBox="0 0 24 24"
          className="w-4 h-4 fill-current text-[#003087]"
        >
          <path d="M7.076 21.337H2.47a.641.641 0 01-.633-.74L4.944.901C5.026.382 5.474 0 5.998 0h7.46c2.57 0 4.578.543 5.69 1.81 1.01 1.15 1.304 2.42 1.012 4.287-.023.143-.047.288-.077.437-.983 5.05-4.349 6.797-8.647 6.797h-2.19c-.524 0-.968.382-1.05.9l-1.12 7.106zm14.146-14.42a3.35 3.35 0 00-.607-.541c1.379 3.452-.757 6.553-5.44 6.553H12.95l-.96 6.085h2.96c.525 0 .97-.383 1.05-.9l.71-4.505h1.79c4.162 0 6.605-2.077 7.218-5.742a3.988 3.988 0 00-.496-1.95z" />
        </svg>
      ),
      available: true,
    },
  ];

  const available = methods.filter((m) => m.available);

  return (
    <div className="space-y-2">
      <p className="text-[11px] font-semibold text-white/40 uppercase tracking-wider mb-3">
        {t("Payment Method", "Mode de paiement", "طريقة الدفع")}
      </p>
      <div className="grid grid-cols-2 gap-2">
        {available.map((method) => (
          <button
            key={method.id}
            onClick={() => onChange(method.id)}
            className={`flex items-center gap-2.5 px-3 py-2.5 rounded-xl border text-sm font-medium transition-all ${
              selected === method.id
                ? "border-blue-500/60 bg-blue-500/10 text-white"
                : "border-white/[0.08] bg-white/[0.03] text-white/50 hover:bg-white/[0.06] hover:text-white/70"
            }`}
          >
            <span
              className={
                selected === method.id ? "text-blue-400" : "text-white/40"
              }
            >
              {method.icon}
            </span>
            <span className="truncate text-[13px]">{method.label}</span>
            {selected === method.id && (
              <div className="ml-auto w-4 h-4 rounded-full bg-blue-500 flex items-center justify-center shrink-0">
                <Check className="w-2.5 h-2.5 text-white" />
              </div>
            )}
          </button>
        ))}
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// CARD FORM
// ─────────────────────────────────────────────────────────────────────────────
function CardForm({
  language,
  onValidChange,
}: {
  language: string;
  onValidChange: (valid: boolean, data: Record<string, string>) => void;
}) {
  const t = useTranslate(language);
  const [number, setNumber] = useState("");
  const [expiry, setExpiry] = useState("");
  const [cvc, setCvc] = useState("");
  const [name, setName] = useState("");
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [touched, setTouched] = useState<Record<string, boolean>>({});

  const brand = detectCardBrand(number);

  const validate = useCallback(
    (n: string, e: string, c: string, nm: string) => {
      const errs: Record<string, string> = {};
      const clean = n.replace(/\s/g, "");
      if (clean.length > 0 && clean.length < 13) {
        errs.number = t(
          "Invalid card number",
          "Numéro invalide",
          "رقم غير صالح",
        );
      }
      if (e.length > 0 && e.length < 5) {
        errs.expiry = t("Invalid date", "Date invalide", "تاريخ غير صالح");
      }
      if (e.length === 5) {
        const [mm, yy] = e.split("/").map(Number);
        const now = new Date();
        const year = 2000 + yy;
        if (
          mm < 1 ||
          mm > 12 ||
          year < now.getFullYear() ||
          (year === now.getFullYear() && mm < now.getMonth() + 1)
        ) {
          errs.expiry = t(
            "Card expired",
            "Carte expirée",
            "البطاقة منتهية الصلاحية",
          );
        }
      }
      if (c.length > 0 && c.length < 3) {
        errs.cvc = t("Invalid CVC", "CVC invalide", "CVC غير صالح");
      }
      setErrors(errs);
      const isValid =
        Object.keys(errs).length === 0 &&
        clean.length >= 13 &&
        e.length === 5 &&
        c.length >= 3 &&
        nm.trim().length > 0;
      onValidChange(isValid, { number: clean, expiry: e, cvc: c, name: nm });
      return isValid;
    },
    [onValidChange, t],
  );

  const field =
    "w-full px-4 py-3 rounded-xl bg-white/[0.04] border text-white placeholder:text-white/20 text-sm focus:outline-none transition-colors";
  const borderOk = "border-white/[0.08] focus:border-blue-500/50";
  const borderErr = "border-red-500/50 focus:border-red-500/70";

  return (
    <div className="space-y-3">
      {/* Cardholder name */}
      <div>
        <input
          type="text"
          value={name}
          onChange={(e) => {
            setName(e.target.value);
            validate(number, expiry, cvc, e.target.value);
          }}
          onBlur={() => setTouched((t) => ({ ...t, name: true }))}
          placeholder={t(
            "Name on card",
            "Nom sur la carte",
            "الاسم على البطاقة",
          )}
          className={`${field} ${touched.name && !name.trim() ? borderErr : borderOk}`}
        />
      </div>

      {/* Card number */}
      <div className="relative">
        <input
          type="text"
          inputMode="numeric"
          value={number}
          onChange={(e) => {
            const v = formatCardNumber(e.target.value);
            setNumber(v);
            validate(v, expiry, cvc, name);
          }}
          onBlur={() => setTouched((t) => ({ ...t, number: true }))}
          placeholder="1234 5678 9012 3456"
          maxLength={19}
          className={`${field} pr-16 ${touched.number && errors.number ? borderErr : borderOk}`}
        />
        <div className="absolute right-3 top-1/2 -translate-y-1/2">
          <CardBrandIcon brand={brand} />
        </div>
        {touched.number && errors.number && (
          <p className="text-[11px] text-red-400 mt-1 ml-1">{errors.number}</p>
        )}
      </div>

      {/* Expiry + CVC */}
      <div className="grid grid-cols-2 gap-3">
        <div>
          <input
            type="text"
            inputMode="numeric"
            value={expiry}
            onChange={(e) => {
              const v = formatExpiry(e.target.value);
              setExpiry(v);
              validate(number, v, cvc, name);
            }}
            onBlur={() => setTouched((t) => ({ ...t, expiry: true }))}
            placeholder="MM/YY"
            maxLength={5}
            className={`${field} ${touched.expiry && errors.expiry ? borderErr : borderOk}`}
          />
          {touched.expiry && errors.expiry && (
            <p className="text-[11px] text-red-400 mt-1 ml-1">
              {errors.expiry}
            </p>
          )}
        </div>
        <div>
          <div className="relative">
            <input
              type="text"
              inputMode="numeric"
              value={cvc}
              onChange={(e) => {
                const v = e.target.value
                  .replace(/\D/g, "")
                  .slice(0, brand === "amex" ? 4 : 3);
                setCvc(v);
                validate(number, expiry, v, name);
              }}
              onBlur={() => setTouched((t) => ({ ...t, cvc: true }))}
              placeholder={brand === "amex" ? "4 digits" : "CVC"}
              maxLength={brand === "amex" ? 4 : 3}
              className={`${field} pr-9 ${touched.cvc && errors.cvc ? borderErr : borderOk}`}
            />
            <div className="absolute right-3 top-1/2 -translate-y-1/2 text-white/20">
              <Shield className="w-3.5 h-3.5" />
            </div>
          </div>
          {touched.cvc && errors.cvc && (
            <p className="text-[11px] text-red-400 mt-1 ml-1">{errors.cvc}</p>
          )}
        </div>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// SEPA FORM
// ─────────────────────────────────────────────────────────────────────────────
function SEPAForm({
  language,
  onValidChange,
}: {
  language: string;
  onValidChange: (valid: boolean, data: Record<string, string>) => void;
}) {
  const t = useTranslate(language);
  const [iban, setIban] = useState("");
  const [name, setName] = useState("");
  const [accepted, setAccepted] = useState(false);
  const [touched, setTouched] = useState<Record<string, boolean>>({});

  const isValidIBAN = (v: string) => v.replace(/\s/g, "").length >= 15;

  const check = (i: string, n: string, a: boolean) => {
    const valid = isValidIBAN(i) && n.trim().length > 0 && a;
    onValidChange(valid, { iban: i.replace(/\s/g, ""), name: n });
  };

  return (
    <div className="space-y-3">
      <div className="p-3 rounded-xl bg-blue-500/10 border border-blue-500/20 flex items-start gap-2">
        <Info className="w-4 h-4 text-blue-400 shrink-0 mt-0.5" />
        <p className="text-xs text-blue-300/80">
          {t(
            "SEPA payments take 1–3 business days to process.",
            "Les paiements SEPA prennent 1 à 3 jours ouvrables.",
            "تستغرق مدفوعات SEPA من 1 إلى 3 أيام عمل.",
          )}
        </p>
      </div>
      <input
        type="text"
        value={name}
        onChange={(e) => {
          setName(e.target.value);
          check(iban, e.target.value, accepted);
        }}
        onBlur={() => setTouched((t) => ({ ...t, name: true }))}
        placeholder={t(
          "Account holder name",
          "Titulaire du compte",
          "اسم صاحب الحساب",
        )}
        className="w-full px-4 py-3 rounded-xl bg-white/[0.04] border border-white/[0.08] text-white placeholder:text-white/20 text-sm focus:outline-none focus:border-blue-500/50 transition-colors"
      />
      <div>
        <input
          type="text"
          value={iban}
          onChange={(e) => {
            const v = formatIBAN(e.target.value);
            setIban(v);
            check(v, name, accepted);
          }}
          onBlur={() => setTouched((t) => ({ ...t, iban: true }))}
          placeholder="DE89 3704 0044 0532 0130 00"
          className={`w-full px-4 py-3 rounded-xl bg-white/[0.04] border text-white placeholder:text-white/20 text-sm font-mono focus:outline-none focus:border-blue-500/50 transition-colors uppercase ${
            touched.iban && iban && !isValidIBAN(iban)
              ? "border-red-500/50"
              : "border-white/[0.08]"
          }`}
        />
        {touched.iban && iban && !isValidIBAN(iban) && (
          <p className="text-[11px] text-red-400 mt-1 ml-1">
            {t("Invalid IBAN", "IBAN invalide", "IBAN غير صالح")}
          </p>
        )}
      </div>
      <label className="flex items-start gap-3 cursor-pointer">
        <div
          onClick={() => {
            const v = !accepted;
            setAccepted(v);
            check(iban, name, v);
          }}
          className={`mt-0.5 w-5 h-5 rounded-md border-2 flex items-center justify-center shrink-0 transition-all ${
            accepted
              ? "bg-blue-500 border-blue-500"
              : "border-white/20 bg-white/[0.03]"
          }`}
        >
          {accepted && <Check className="w-3 h-3 text-white" />}
        </div>
        <p className="text-[11px] text-white/40 leading-relaxed">
          {t(
            "I authorize IQXO to send instructions to my bank to debit my account.",
            "J'autorise IQXO à envoyer des instructions à ma banque pour débiter mon compte.",
            "أفوض IQXO بإرسال تعليمات إلى بنكي لخصم حسابي.",
          )}
        </p>
      </label>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// MAIN COMPONENT
// ─────────────────────────────────────────────────────────────────────────────
interface StripePricingPageProps {
  open?: boolean;
  onClose?: () => void;
  forceOpen?: boolean;
  planStatus?: string;
  trialEndsAt?: Date | null;
}

export function StripePricingPage({
  open = true,
  onClose,
  forceOpen = false,
  planStatus,
  trialEndsAt,
}: StripePricingPageProps) {
  const { language, setPlanStatus, user } = useApp();
  const isRTL = language === "ar";
  const t = useTranslate(language);

  const [billing, setBilling] = useState<BillingCycle>("yearly");
  const [step, setStep] = useState<PageStep>("plans");
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>("card");
  const [isPaymentValid, setIsPaymentValid] = useState(false);
  const [paymentData, setPaymentData] = useState<Record<string, string>>({});
  const [loadingPlan, setLoadingPlan] = useState<BillingCycle | null>(null);
  const [trialError, setTrialError] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string>("");
  const [processingDots, setProcessingDots] = useState(0);

  // Animate processing dots
  useEffect(() => {
    if (step !== "processing") return;
    const id = setInterval(() => setProcessingDots((d) => (d + 1) % 4), 400);
    return () => clearInterval(id);
  }, [step]);

  // ── Subscribe via Stripe Checkout redirect ──────────────────────────────
  const handleSubscribeCheckout = async (cycle: BillingCycle) => {
    if (!user) return;
    setLoadingPlan(cycle);
    try {
      const res = await fetch(`${BACKEND_URL}/create-checkout-session`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          billing: cycle,
          userId: user.id,
          userEmail: user.email,
        }),
      });
      const data = await res.json();
      if (data.url) {
        window.location.href = data.url;
      } else {
        throw new Error(data.error || "No checkout URL returned");
      }
    } catch (err: any) {
      setErrorMessage(
        err.message ||
          t(
            "Payment failed. Please try again.",
            "Paiement échoué.",
            "فشل الدفع.",
          ),
      );
      setStep("error");
    } finally {
      setLoadingPlan(null);
    }
  };

  // ── Handle direct payment (card / SEPA / PayPal) ────────────────────────
  const handleDirectPayment = async () => {
    if (!user || !isPaymentValid) return;
    setStep("processing");

    try {
      // For card/SEPA, use Stripe Payment Intents via backend
      // In production this would create a PaymentIntent and confirm via Stripe.js
      // Here we use Stripe Checkout as the reliable path
      const res = await fetch(`${BACKEND_URL}/create-checkout-session`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          priceId: billing,
          userId: user.id,
          userEmail: user.email,
          paymentMethod: paymentMethod,
        }),
      });
      const data = await res.json();
      if (data.url) {
        window.location.href = data.url;
      } else {
        throw new Error(data.error || "Checkout failed");
      }
    } catch (err: any) {
      setErrorMessage(
        err.message ||
          t(
            "Payment could not be processed.",
            "Paiement non traité.",
            "لم يتمكن من معالجة الدفع.",
          ),
      );
      setStep("error");
    }
  };

  // ── Free Trial ──────────────────────────────────────────────────────────
  const handleTrial = async () => {
    if (!user) return;
    setTrialError(null);
    try {
      const res = await fetch(`${BACKEND_URL}/start-trial`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ userId: user.id }),
      });
      const data = await res.json();
      if (res.status === 409) {
        setTrialError(
          t(
            "This account has already used its free trial. Please subscribe to continue.",
            "Ce compte a déjà utilisé l'essai gratuit. Veuillez vous abonner.",
            "هذا الحساب استخدم التجربة المجانية من قبل. يرجى الاشتراك للمتابعة.",
          ),
        );
        return;
      }
      if (!res.ok) throw new Error(data.error);
      setPlanStatus("free_trial", new Date(data.trialEndsAt));
      setStep("success");
    } catch (err: any) {
      setTrialError(
        t(
          "Something went wrong. Please try again.",
          "Une erreur est survenue.",
          "حدث خطأ.",
        ),
      );
    }
  };

  // ── Manage Portal ───────────────────────────────────────────────────────
  const handleManagePortal = async () => {
    if (!user) return;
    try {
      const res = await fetch(`${BACKEND_URL}/create-portal-session`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ userId: user.id }),
      });
      const data = await res.json();
      if (data.url) window.open(data.url, "_blank");
    } catch {
      // Silent fail
    }
  };

  const features = [
    { icon: Mic, en: "Voice → Event", fr: "Voix → Événement", ar: "صوت ← حدث" },
    {
      icon: ImageIcon,
      en: "Image / PDF extraction",
      fr: "Extraction Image / PDF",
      ar: "استخراج صورة / PDF",
    },
    {
      icon: Brain,
      en: "Smart analysis",
      fr: "Analyse intelligente",
      ar: "تحليل ذكي",
    },
    {
      icon: Lightbulb,
      en: "AI Suggestions",
      fr: "Suggestions IA",
      ar: "اقتراحات AI",
    },
    {
      icon: Sparkles,
      en: "Any future AI feature",
      fr: "Toute future fonction IA",
      ar: "أي ميزة AI مستقبلية",
    },
  ];

  if (!open) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-50 flex items-end justify-center bg-black/70 backdrop-blur-sm"
        onClick={forceOpen ? undefined : onClose}
      >
        <motion.div
          initial={{ y: "100%" }}
          animate={{ y: 0 }}
          exit={{ y: "100%" }}
          transition={{ type: "spring", damping: 30, stiffness: 300 }}
          onClick={(e) => e.stopPropagation()}
          className={`w-full max-w-lg bg-[#0d0d12] rounded-t-3xl border-t border-white/[0.08] max-h-[95vh] overflow-y-auto relative ${isRTL ? "text-right" : ""}`}
          dir={isRTL ? "rtl" : "ltr"}
        >
          {/* Ambient glow */}
          <div className="absolute top-0 left-1/2 -translate-x-1/2 w-80 h-48 bg-gradient-to-b from-blue-500/15 via-purple-500/8 to-transparent blur-3xl pointer-events-none rounded-full" />

          {/* Drag handle */}
          <div className="flex justify-center pt-3 pb-1">
            <div className="w-10 h-1 rounded-full bg-white/20" />
          </div>

          {/* Close button */}
          {onClose && !forceOpen && (
            <button
              onClick={onClose}
              className="absolute top-4 right-4 z-10 p-2 rounded-full bg-white/[0.06] hover:bg-white/10 transition-colors"
            >
              <X className="w-4 h-4 text-white/50" />
            </button>
          )}

          <div className="relative px-5 pb-8 pt-2">
            <AnimatePresence mode="wait">
              {/* ─────────────────── PLANS STEP ───────────────────────────── */}
              {step === "plans" && (
                <motion.div
                  key="plans"
                  initial={{ opacity: 0, y: 12 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -12 }}
                  className="space-y-5 pt-3"
                >
                  {/* Header */}
                  <div className="text-center">
                    <motion.div
                      animate={{ y: [0, -4, 0] }}
                      transition={{
                        duration: 3,
                        repeat: Infinity,
                        ease: "easeInOut",
                      }}
                      className="inline-flex p-3.5 rounded-2xl bg-gradient-to-br from-amber-400/20 to-amber-500/5 mb-3"
                    >
                      <Crown className="w-7 h-7 text-amber-400" />
                    </motion.div>
                    <h2 className="text-xl font-bold text-white">
                      {t(
                        "Unlock IQXO Pro",
                        "Débloquer IQXO Pro",
                        "فعّل IQXO Pro",
                      )}
                    </h2>
                    <p className="text-sm text-white/40 mt-1">
                      {t(
                        "300 AI requests / month · All features",
                        "300 requêtes IA / mois · Tout inclus",
                        "300 طلب AI / شهر · جميع الميزات",
                      )}
                    </p>
                  </div>

                  {/* Expired / trial-ending banner */}
                  {planStatus === "expired" && (
                    <motion.div
                      initial={{ opacity: 0, y: -8 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="flex items-center gap-3 p-3 rounded-xl bg-amber-500/10 border border-amber-500/25"
                    >
                      <Clock className="w-4 h-4 text-amber-400 shrink-0" />
                      <p className="text-xs text-amber-300">
                        {t(
                          "Your free trial has ended. Choose a plan to continue.",
                          "Votre essai gratuit a expiré. Choisissez un plan.",
                          "انتهت التجربة المجانية. اختر خطة للمتابعة.",
                        )}
                      </p>
                    </motion.div>
                  )}

                  {/* Billing toggle */}
                  <div className="flex items-center justify-center p-1 bg-white/[0.04] rounded-2xl gap-1">
                    {(["monthly", "yearly"] as BillingCycle[]).map((cycle) => (
                      <button
                        key={cycle}
                        onClick={() => setBilling(cycle)}
                        className={`flex-1 flex items-center justify-center gap-1.5 py-2 rounded-xl text-sm font-semibold transition-all ${
                          billing === cycle
                            ? "bg-white/10 text-white shadow"
                            : "text-white/40 hover:text-white/60"
                        }`}
                      >
                        {cycle === "monthly"
                          ? t("Monthly", "Mensuel", "شهري")
                          : t("Yearly", "Annuel", "سنوي")}
                        {cycle === "yearly" && (
                          <span
                            className={`text-[10px] px-1.5 py-0.5 rounded-full font-bold ${
                              billing === "yearly"
                                ? "bg-emerald-500/25 text-emerald-400"
                                : "bg-emerald-500/10 text-emerald-500/60"
                            }`}
                          >
                            -{PRICING.savingsPct}%
                          </span>
                        )}
                      </button>
                    ))}
                  </div>

                  {/* Main plan card */}
                  <div className="relative rounded-2xl overflow-hidden">
                    {/* Subtle gradient border */}
                    <div className="absolute inset-0 rounded-2xl bg-gradient-to-br from-blue-500/30 via-purple-500/20 to-transparent p-[1px]">
                      <div className="h-full w-full rounded-2xl bg-[#0d0d12]" />
                    </div>

                    <div className="relative p-5">
                      {/* Best Value badge */}
                      {billing === "yearly" && (
                        <div className="absolute -top-[1px] left-1/2 -translate-x-1/2 px-3 py-0.5 rounded-b-xl bg-gradient-to-r from-blue-500 to-purple-500 text-[10px] font-bold text-white shadow">
                          {t("Best Value", "Meilleur rapport", "الأفضل قيمة")}
                        </div>
                      )}

                      <div className="flex items-end justify-between mb-4 mt-2">
                        <div>
                          <AnimatePresence mode="wait">
                            <motion.div
                              key={billing}
                              initial={{ opacity: 0, y: -6 }}
                              animate={{ opacity: 1, y: 0 }}
                              exit={{ opacity: 0, y: 6 }}
                              className="flex items-baseline gap-1"
                            >
                              <span className="text-4xl font-black text-white">
                                {billing === "monthly"
                                  ? `${PRICING.monthlyEUR}€`
                                  : `${PRICING.yearlyEUR}€`}
                              </span>
                              <span className="text-white/30 text-sm">
                                {billing === "monthly"
                                  ? t("/mo", "/mois", "/شهر")
                                  : t("/yr", "/an", "/سنة")}
                              </span>
                            </motion.div>
                          </AnimatePresence>
                          <p className="text-xs text-white/30 mt-0.5">
                            {billing === "monthly"
                              ? t(
                                  "billed monthly",
                                  "facturé mensuellement",
                                  "فوترة شهرية",
                                )
                              : t(
                                  "billed once a year",
                                  "facturé annuellement",
                                  "فوترة سنوية",
                                )}
                          </p>
                        </div>
                        {billing === "yearly" && (
                          <div className="text-right">
                            <p className="text-sm font-semibold text-emerald-400">
                              {PRICING.yearlyPerMonth}€/mo
                            </p>
                            <p className="text-[10px] text-white/30">
                              {t("instead of", "au lieu de", "بدلاً من")}{" "}
                              {PRICING.monthlyEUR}€
                            </p>
                          </div>
                        )}
                      </div>

                      {/* AI usage chip */}
                      <div className="flex items-center gap-2 mb-4 px-3 py-2 rounded-xl bg-blue-500/10 border border-blue-500/20">
                        <Zap className="w-3.5 h-3.5 text-blue-400 shrink-0" />
                        <p className="text-sm font-semibold text-white">
                          {t(
                            "300 AI requests / month",
                            "300 requêtes IA / mois",
                            "300 طلب AI / شهر",
                          )}
                        </p>
                      </div>

                      {/* Features */}
                      <div className="space-y-2 mb-5">
                        {features.map((f, i) => (
                          <motion.div
                            key={i}
                            initial={{ opacity: 0, x: -8 }}
                            animate={{ opacity: 1, x: 0 }}
                            transition={{ delay: 0.05 * i }}
                            className="flex items-center gap-2.5"
                          >
                            <div className="h-6 w-6 rounded-lg bg-white/[0.06] flex items-center justify-center shrink-0">
                              <f.icon className="w-3.5 h-3.5 text-white/50" />
                            </div>
                            <span className="text-sm text-white/70 flex-1">
                              {t(f.en, f.fr, f.ar)}
                            </span>
                            <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                          </motion.div>
                        ))}
                      </div>

                      {/* Subscribe CTA */}
                      <motion.button
                        whileHover={{ scale: 1.01 }}
                        whileTap={{ scale: 0.98 }}
                        onClick={() => setStep("payment")}
                        disabled={loadingPlan !== null}
                        className="w-full py-3.5 rounded-xl bg-gradient-to-r from-blue-600 to-purple-600 text-white font-semibold text-sm shadow-lg shadow-blue-500/20 hover:shadow-blue-500/30 transition-all disabled:opacity-50 flex items-center justify-center gap-2"
                      >
                        {billing === "monthly"
                          ? t(
                              `Subscribe · ${PRICING.monthlyEUR}€/mo`,
                              `S'abonner · ${PRICING.monthlyEUR}€/mois`,
                              `اشترك · ${PRICING.monthlyEUR}€/شهر`,
                            )
                          : t(
                              `Subscribe · ${PRICING.yearlyEUR}€/yr`,
                              `S'abonner · ${PRICING.yearlyEUR}€/an`,
                              `اشترك · ${PRICING.yearlyEUR}€/سنة`,
                            )}
                        <ChevronRight className="w-4 h-4" />
                      </motion.button>
                    </div>
                  </div>

                  {/* Free trial */}
                  <motion.button
                    whileHover={{ scale: 1.01 }}
                    whileTap={{ scale: 0.98 }}
                    onClick={handleTrial}
                    className="w-full p-4 rounded-2xl border border-white/[0.08] bg-white/[0.03] hover:bg-white/[0.05] transition-all flex items-center gap-4"
                  >
                    <div className="p-2 rounded-xl bg-emerald-500/10 shrink-0">
                      <Gift className="w-5 h-5 text-emerald-400" />
                    </div>
                    <div className="flex-1 text-left">
                      <p className="font-semibold text-white text-sm">
                        {t(
                          "2-Day Free Trial",
                          "Essai gratuit 2 jours",
                          "تجربة مجانية يومان",
                        )}
                      </p>
                      <p className="text-xs text-white/40">
                        {t(
                          "Full access · No credit card needed",
                          "Accès complet · Sans carte bancaire",
                          "وصول كامل · بدون بطاقة ائتمانية",
                        )}
                      </p>
                    </div>
                    <span className="text-base font-black text-emerald-400">
                      Free
                    </span>
                  </motion.button>

                  {/* Trial error */}
                  <AnimatePresence>
                    {trialError && (
                      <motion.div
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: "auto" }}
                        exit={{ opacity: 0, height: 0 }}
                        className="flex items-start gap-2 p-3 rounded-xl bg-red-500/10 border border-red-500/20"
                      >
                        <AlertCircle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
                        <p className="text-xs text-red-300">{trialError}</p>
                      </motion.div>
                    )}
                  </AnimatePresence>

                  {/* Security */}
                  <div className="flex items-center justify-center gap-2 text-white/25 text-[11px]">
                    <Lock className="w-3 h-3" />
                    <span>
                      {t(
                        "Encrypted & secured by Stripe",
                        "Chiffré par Stripe",
                        "مشفر بواسطة Stripe",
                      )}
                    </span>
                  </div>
                </motion.div>
              )}

              {/* ─────────────────── PAYMENT STEP ─────────────────────────── */}
              {step === "payment" && (
                <motion.div
                  key="payment"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  className="space-y-5 pt-3"
                >
                  {/* Back + Header */}
                  <div className="flex items-center gap-3">
                    <button
                      onClick={() => setStep("plans")}
                      className="p-2 rounded-xl bg-white/[0.05] hover:bg-white/[0.08] transition-colors"
                    >
                      <ArrowLeft className="w-4 h-4 text-white/60" />
                    </button>
                    <div>
                      <h2 className="text-base font-bold text-white">
                        {t(
                          "Payment Details",
                          "Détails de paiement",
                          "تفاصيل الدفع",
                        )}
                      </h2>
                      <p className="text-xs text-white/40">
                        {billing === "monthly"
                          ? `${PRICING.monthlyEUR}€ / ${t("month", "mois", "شهر")}`
                          : `${PRICING.yearlyEUR}€ / ${t("year", "an", "سنة")}`}
                      </p>
                    </div>
                  </div>

                  {/* Order summary */}
                  <div className="p-3 rounded-xl bg-white/[0.04] border border-white/[0.06] flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Crown className="w-4 h-4 text-amber-400" />
                      <span className="text-sm text-white/80 font-medium">
                        IQXO Pro ·{" "}
                        {billing === "monthly"
                          ? t("Monthly", "Mensuel", "شهري")
                          : t("Yearly", "Annuel", "سنوي")}
                      </span>
                    </div>
                    <span className="text-sm font-bold text-white">
                      {billing === "monthly"
                        ? `${PRICING.monthlyEUR}€`
                        : `${PRICING.yearlyEUR}€`}
                    </span>
                  </div>

                  {/* Payment method selector */}
                  <PaymentMethodSelector
                    selected={paymentMethod}
                    onChange={(m) => {
                      setPaymentMethod(m);
                      setIsPaymentValid(false);
                    }}
                    language={language}
                  />

                  {/* Payment form */}
                  <AnimatePresence mode="wait">
                    {paymentMethod === "card" && (
                      <motion.div
                        key="card-form"
                        initial={{ opacity: 0, y: 8 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -8 }}
                      >
                        <CardForm
                          language={language}
                          onValidChange={(valid, data) => {
                            setIsPaymentValid(valid);
                            setPaymentData(data);
                          }}
                        />
                      </motion.div>
                    )}

                    {paymentMethod === "sepa" && (
                      <motion.div
                        key="sepa-form"
                        initial={{ opacity: 0, y: 8 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -8 }}
                      >
                        <SEPAForm
                          language={language}
                          onValidChange={(valid, data) => {
                            setIsPaymentValid(valid);
                            setPaymentData(data);
                          }}
                        />
                      </motion.div>
                    )}

                    {(paymentMethod === "apple_pay" ||
                      paymentMethod === "google_pay") && (
                      <motion.div
                        key="wallet-form"
                        initial={{ opacity: 0, y: 8 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -8 }}
                        className="p-4 rounded-xl bg-white/[0.04] border border-white/[0.06] text-center"
                      >
                        <p className="text-sm text-white/60 mb-3">
                          {paymentMethod === "apple_pay"
                            ? t(
                                "Tap the button below to pay with Apple Pay.",
                                "Appuyez sur le bouton pour payer avec Apple Pay.",
                                "اضغط الزر أدناه للدفع بـ Apple Pay.",
                              )
                            : t(
                                "Tap the button below to pay with Google Pay.",
                                "Appuyez sur le bouton pour payer avec Google Pay.",
                                "اضغط الزر أدناه للدفع بـ Google Pay.",
                              )}
                        </p>
                        {/* Wallet button placeholder — triggers Stripe's Payment Request Button */}
                        <div
                          className="h-12 w-full rounded-xl bg-black border border-white/10 flex items-center justify-center cursor-pointer hover:bg-white/[0.02] transition-colors"
                          onClick={() => {
                            setIsPaymentValid(true);
                          }}
                        >
                          {paymentMethod === "apple_pay" ? (
                            <span
                              className="text-white font-medium tracking-tight"
                              style={{ fontFamily: "-apple-system" }}
                            >
                              {" "}
                              Pay
                            </span>
                          ) : (
                            <span className="text-white/80 text-sm font-medium">
                              Buy with G Pay
                            </span>
                          )}
                        </div>
                      </motion.div>
                    )}

                    {paymentMethod === "paypal" && (
                      <motion.div
                        key="paypal-form"
                        initial={{ opacity: 0, y: 8 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -8 }}
                        className="p-4 rounded-xl bg-white/[0.04] border border-white/[0.06] text-center"
                      >
                        <p className="text-sm text-white/60 mb-3">
                          {t(
                            "You'll be redirected to PayPal to complete payment.",
                            "Vous serez redirigé vers PayPal pour finaliser le paiement.",
                            "ستتم إعادة توجيهك إلى PayPal لإتمام الدفع.",
                          )}
                        </p>
                        <button
                          onClick={() => setIsPaymentValid(true)}
                          className="w-full h-12 rounded-xl bg-[#FFC439] flex items-center justify-center gap-2 hover:bg-[#f5b731] transition-colors"
                        >
                          <svg
                            viewBox="0 0 24 24"
                            className="h-5 fill-[#003087]"
                          >
                            <path d="M7.076 21.337H2.47a.641.641 0 01-.633-.74L4.944.901C5.026.382 5.474 0 5.998 0h7.46c2.57 0 4.578.543 5.69 1.81 1.01 1.15 1.304 2.42 1.012 4.287-.023.143-.047.288-.077.437-.983 5.05-4.349 6.797-8.647 6.797h-2.19c-.524 0-.968.382-1.05.9l-1.12 7.106z" />
                          </svg>
                          <span className="font-bold text-[#003087]">
                            PayPal
                          </span>
                        </button>
                      </motion.div>
                    )}
                  </AnimatePresence>

                  {/* Security badges */}
                  <div className="flex items-center justify-center gap-4 py-1">
                    {[
                      { icon: Lock, label: t("Encrypted", "Chiffré", "مشفر") },
                      { icon: Shield, label: "PCI DSS" },
                      {
                        icon: RefreshCw,
                        label: t(
                          "Cancel anytime",
                          "Résiliable",
                          "قابل للإلغاء",
                        ),
                      },
                    ].map(({ icon: Icon, label }) => (
                      <div
                        key={label}
                        className="flex items-center gap-1.5 text-white/25"
                      >
                        <Icon className="w-3 h-3" />
                        <span className="text-[10px]">{label}</span>
                      </div>
                    ))}
                  </div>

                  {/* Pay CTA */}
                  <motion.button
                    whileHover={{ scale: isPaymentValid ? 1.01 : 1 }}
                    whileTap={{ scale: isPaymentValid ? 0.98 : 1 }}
                    onClick={
                      paymentMethod === "card" || paymentMethod === "sepa"
                        ? handleDirectPayment
                        : handleSubscribeCheckout.bind(null, billing)
                    }
                    disabled={!isPaymentValid}
                    className={`w-full py-4 rounded-xl font-semibold text-sm transition-all flex items-center justify-center gap-2 ${
                      isPaymentValid
                        ? "bg-gradient-to-r from-blue-600 to-purple-600 text-white shadow-lg shadow-blue-500/25 hover:shadow-blue-500/40"
                        : "bg-white/[0.05] text-white/25 cursor-not-allowed"
                    }`}
                  >
                    <Lock className="w-4 h-4" />
                    {billing === "monthly"
                      ? t(
                          `Pay ${PRICING.monthlyEUR}€`,
                          `Payer ${PRICING.monthlyEUR}€`,
                          `ادفع ${PRICING.monthlyEUR}€`,
                        )
                      : t(
                          `Pay ${PRICING.yearlyEUR}€`,
                          `Payer ${PRICING.yearlyEUR}€`,
                          `ادفع ${PRICING.yearlyEUR}€`,
                        )}
                  </motion.button>

                  <p className="text-center text-[11px] text-white/25 pb-2">
                    {t(
                      "7-day money-back guarantee · Cancel anytime · VAT 20% included",
                      "Remboursement 7j · Résiliation libre · TVA 20% incluse",
                      "ضمان استرداد 7 أيام · إلغاء مجاني · ضريبة 20% مضمنة",
                    )}
                  </p>
                </motion.div>
              )}

              {/* ─────────────────── PROCESSING STEP ─────────────────────── */}
              {step === "processing" && (
                <motion.div
                  key="processing"
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  className="flex flex-col items-center justify-center py-16 gap-5"
                >
                  <div className="relative">
                    <div className="w-16 h-16 rounded-full border-2 border-blue-500/20 flex items-center justify-center">
                      <motion.div
                        animate={{ rotate: 360 }}
                        transition={{
                          duration: 1.2,
                          repeat: Infinity,
                          ease: "linear",
                        }}
                        className="absolute inset-0 rounded-full border-2 border-transparent border-t-blue-500"
                      />
                      <Lock className="w-6 h-6 text-blue-400" />
                    </div>
                  </div>
                  <div className="text-center">
                    <p className="text-white font-semibold">
                      {t(
                        "Processing payment",
                        "Traitement en cours",
                        "جارٍ المعالجة",
                      )}
                      {"...".slice(0, processingDots + 1)}
                    </p>
                    <p className="text-sm text-white/40 mt-1">
                      {t(
                        "Please don't close this window",
                        "Ne fermez pas cette fenêtre",
                        "لا تغلق هذه النافذة",
                      )}
                    </p>
                  </div>
                </motion.div>
              )}

              {/* ─────────────────── SUCCESS STEP ─────────────────────────── */}
              {step === "success" && (
                <motion.div
                  key="success"
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0 }}
                  className="flex flex-col items-center text-center py-12 gap-5"
                >
                  <motion.div
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    transition={{
                      type: "spring",
                      delay: 0.1,
                      stiffness: 300,
                      damping: 20,
                    }}
                    className="relative"
                  >
                    <div className="w-20 h-20 rounded-full bg-emerald-500/15 flex items-center justify-center">
                      <CheckCircle2 className="w-10 h-10 text-emerald-400" />
                    </div>
                    {/* Confetti particles */}
                    {[...Array(6)].map((_, i) => (
                      <motion.div
                        key={i}
                        initial={{ scale: 0, x: 0, y: 0 }}
                        animate={{
                          scale: [0, 1, 0],
                          x: [0, (i % 2 === 0 ? 1 : -1) * (20 + i * 8)],
                          y: [0, -(20 + i * 6)],
                        }}
                        transition={{ delay: 0.3 + i * 0.05, duration: 0.8 }}
                        className="absolute top-1/2 left-1/2 w-2 h-2 rounded-full"
                        style={{
                          background: [
                            "#3b82f6",
                            "#8b5cf6",
                            "#10b981",
                            "#f59e0b",
                            "#ef4444",
                            "#06b6d4",
                          ][i],
                        }}
                      />
                    ))}
                  </motion.div>

                  <div>
                    <h2 className="text-2xl font-bold text-white">
                      {t(
                        "You're all set! 🎉",
                        "Tout est prêt ! 🎉",
                        "أنت جاهز! 🎉",
                      )}
                    </h2>
                    <p className="text-white/50 text-sm mt-2 max-w-xs">
                      {t(
                        "Welcome to IQXO Pro. All AI features are now unlocked.",
                        "Bienvenue dans IQXO Pro. Toutes les fonctionnalités IA sont disponibles.",
                        "مرحباً بك في IQXO Pro. جميع ميزات AI متاحة الآن.",
                      )}
                    </p>
                  </div>

                  <button
                    onClick={onClose}
                    className="px-8 py-3.5 rounded-xl bg-gradient-to-r from-blue-600 to-purple-600 text-white font-semibold text-sm hover:shadow-lg hover:shadow-blue-500/25 transition-all"
                  >
                    {t(
                      "Start Using IQXO",
                      "Commencer à utiliser IQXO",
                      "ابدأ باستخدام IQXO",
                    )}
                  </button>
                </motion.div>
              )}

              {/* ─────────────────── ERROR STEP ───────────────────────────── */}
              {step === "error" && (
                <motion.div
                  key="error"
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0 }}
                  className="flex flex-col items-center text-center py-12 gap-5"
                >
                  <motion.div
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    transition={{ type: "spring", delay: 0.1 }}
                    className="w-20 h-20 rounded-full bg-red-500/10 flex items-center justify-center"
                  >
                    <XCircle className="w-10 h-10 text-red-400" />
                  </motion.div>
                  <div>
                    <h2 className="text-xl font-bold text-white">
                      {t("Payment Failed", "Paiement échoué", "فشل الدفع")}
                    </h2>
                    <p className="text-white/40 text-sm mt-2 max-w-xs">
                      {errorMessage ||
                        t(
                          "Something went wrong. Please try again.",
                          "Une erreur est survenue. Veuillez réessayer.",
                          "حدث خطأ. يرجى المحاولة مرة أخرى.",
                        )}
                    </p>
                  </div>
                  <div className="flex gap-3">
                    <button
                      onClick={() => setStep("payment")}
                      className="px-6 py-3 rounded-xl bg-gradient-to-r from-blue-600 to-purple-600 text-white font-semibold text-sm"
                    >
                      {t("Try Again", "Réessayer", "حاول مرة أخرى")}
                    </button>
                    {onClose && (
                      <button
                        onClick={onClose}
                        className="px-6 py-3 rounded-xl bg-white/[0.06] text-white/60 font-semibold text-sm hover:bg-white/[0.09] transition-colors"
                      >
                        {t("Cancel", "Annuler", "إلغاء")}
                      </button>
                    )}
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}
